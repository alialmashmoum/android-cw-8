package com.example.pokemon1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ArrayList<Pokemon>  pokeball = new ArrayList<>();

        Pokemon p1 = new Pokemon("Arbok",R.drawable.arbok,95,69,164);
        Pokemon p2 = new Pokemon("Blastoise",R.drawable.blastoise,83,100,183);
        Pokemon p3 = new Pokemon("Arcanine",R.drawable.arcanine,110,80,190);
        Pokemon p4 = new Pokemon("Dugtrio",R.drawable.dugtrio,100,50,150);
        Pokemon p5 = new Pokemon("Charizard",R.drawable.charizard,84,78,162);

        pokeball.add(p1);//0
        pokeball.add(p2);//1
        pokeball.add(p3);//2
        pokeball.add(p4);//3
        pokeball.add(p5);//4


        RecyclerView z = findViewById(R.id.recyclerView);

        z.setHasFixedSize(true);
        RecyclerView.LayoutManager ln = new LinearLayoutManager(this);
        z.setLayoutManager(ln);

        PokemonAdapter n = new PokemonAdapter(pokeball,this);

        z.setAdapter(n);

    }
}